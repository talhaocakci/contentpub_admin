var AWS = require('aws-sdk')

var s3 = new AWS.S3({
    signatureVersion : 'v4',
    region: "us-east-1"
});

exports.handler = async (event) => {
   
   const url = s3.getSignedUrl('getObject',{
       Bucket: event.pathParameters.bucket,
       Key: event.pathParameters.object,
       Expires: 6000
   });
   
  
   const username = event.requestContext.authorizer.claims['cognito:username'];

    const response = {
        statusCode: 200,
        body: JSON.stringify(
            {
                url: url
            }),
        isBase64Encoded: false,
        headers:{
              'Access-Control-Allow-Origin':'*',
               'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
               'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS,POST'
        }
    };
    
    return response;

};
